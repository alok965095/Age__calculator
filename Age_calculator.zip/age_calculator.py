from tkinter import *
from tkinter import ttk
from datetime import date
from tkinter import messagebox
root  = Tk()
root.geometry("400x500")
root.resizable(0,0)
root.title("AGE CALCULATOR")
root.config(bg = "#f9e0e4")
def cal():
    c = combo1.get()
    count = 0
    month_ = ["January","February","March","April","May","June","July","August","September","October","November","December"]
    for i in month_:
        if i == c:
            count+=1
            _month = count
        else:
            count+=1
    day = int(combo2.get())
    year = int(y.get())
    today = date.today()
    birthdate = date(year, _month, day)
    
    agem = today.month - birthdate.month
    aged = today.day - birthdate.day
    if today.year < year :
        messagebox.showerror("Age Calculator","That not Posible")
    else:
        age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))
        age = str(age)
    ageis = f"You are {age} year old"
    a = Label(root,text = ageis,font = "verdana 13 bold",bg = "#f9e0e4",fg = "black").place(x = 10, y = 380)
img = PhotoImage(file = "a.png")
lbl = Label(root,image=img,borderwidth=0).pack()
da = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"]
day = Label(root,text = "Enter Day",font = "verdana 13 bold",bg = "#f9e0e4").place(x = 10, y = 200)
combo2 = ttk.Combobox(root,values=da,font="Roboto 14",state="r")
combo2.place(x =150,y = 200 )
month = ["January","February","March","April","May","June","July","August","September","October","November","December"]
mon = Label(root,text = "Enter Month",font = "verdana 13 bold",bg = "#f9e0e4")
mon.place(x = 10, y = 240)
combo1 = ttk.Combobox(root,values=month,font="Roboto 14",state="r")
combo1.place(x=150,y=240)
y = StringVar()
ye = Label(root,text = "Enter Year",font = "verdana 13 bold",bg = "#f9e0e4").place(x = 10, y = 280)
year  = Entry(root,textvariable=y,font = "verdana 13 bold",borderwidth=2,width=20).place(x =150,y = 280 )
btn = Button(root,text = "Calculate",font = "verdana 13 bold",borderwidth=4,bg = "green",command = cal).place(x=150,y = 320)
root.mainloop()